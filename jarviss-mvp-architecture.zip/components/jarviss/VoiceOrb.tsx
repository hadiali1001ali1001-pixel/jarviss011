'use client'

import { cn } from '@/lib/utils'
import type { VoiceState } from '@/types/voice'

interface VoiceOrbProps {
  state: VoiceState
  audioLevel?: number
  onClick?: () => void
  size?: 'sm' | 'md' | 'lg'
  disabled?: boolean
}

export function VoiceOrb({
  state,
  audioLevel = 0,
  onClick,
  size = 'lg',
  disabled = false,
}: VoiceOrbProps) {
  const sizeClasses = {
    sm: 'w-24 h-24',
    md: 'w-40 h-40',
    lg: 'w-56 h-56',
  }

  const innerSizeClasses = {
    sm: 'w-20 h-20',
    md: 'w-32 h-32',
    lg: 'w-44 h-44',
  }

  const getStateClasses = () => {
    switch (state) {
      case 'listening':
        return 'animate-pulse-listening'
      case 'processing':
        return 'animate-spin-slow'
      case 'speaking':
        return 'animate-pulse-glow'
      case 'error':
        return 'animate-pulse'
      default:
        return 'animate-pulse-glow'
    }
  }

  const getGlowColor = () => {
    switch (state) {
      case 'listening':
        return 'from-cyan-400 via-cyan-500 to-teal-500'
      case 'processing':
        return 'from-cyan-500 via-blue-500 to-purple-500'
      case 'speaking':
        return 'from-cyan-400 via-teal-400 to-emerald-400'
      case 'error':
        return 'from-red-500 via-red-600 to-red-700'
      default:
        return 'from-cyan-500/50 via-cyan-600/50 to-teal-600/50'
    }
  }

  const getStatusText = () => {
    switch (state) {
      case 'listening':
        return 'Listening...'
      case 'processing':
        return 'Processing...'
      case 'speaking':
        return 'Speaking...'
      case 'error':
        return 'Click to type'
      default:
        return 'Click to activate'
    }
  }

  // Dynamic scale based on audio level when listening
  const dynamicScale = state === 'listening' ? 1 + audioLevel * 0.15 : 1

  return (
    <button
      onClick={onClick}
      className={cn(
        'relative flex items-center justify-center rounded-full transition-all duration-300',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        sizeClasses[size],
        onClick && 'cursor-pointer hover:scale-105',
      )}
      style={{ transform: `scale(${dynamicScale})` }}
      aria-label={getStatusText()}
    >
      {/* Outer glow ring */}
      <div
        className={cn(
          'absolute inset-0 rounded-full bg-gradient-to-r opacity-30 blur-xl',
          getGlowColor(),
          getStateClasses(),
        )}
      />

      {/* Ripple effects for listening state */}
      {state === 'listening' && (
        <>
          <div className="absolute inset-0 rounded-full border border-cyan-400/30 animate-ripple" />
          <div className="absolute inset-0 rounded-full border border-cyan-400/20 animate-ripple" style={{ animationDelay: '0.5s' }} />
          <div className="absolute inset-0 rounded-full border border-cyan-400/10 animate-ripple" style={{ animationDelay: '1s' }} />
        </>
      )}

      {/* Middle glow ring */}
      <div
        className={cn(
          'absolute rounded-full bg-gradient-to-r opacity-50 blur-md',
          innerSizeClasses[size],
          getGlowColor(),
        )}
      />

      {/* Inner orb */}
      <div
        className={cn(
          'relative rounded-full bg-gradient-to-br',
          'shadow-2xl',
          innerSizeClasses[size],
          getGlowColor(),
        )}
      >
        {/* Glass overlay */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-b from-white/20 to-transparent" />
        
        {/* Center highlight */}
        <div className="absolute inset-4 rounded-full bg-gradient-to-br from-white/10 to-transparent" />
        
        {/* Processing spinner */}
        {state === 'processing' && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-12 h-12 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          </div>
        )}

        {/* Audio level bars for speaking state */}
        {state === 'speaking' && (
          <div className="absolute inset-0 flex items-center justify-center gap-1">
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="w-1.5 bg-white/80 rounded-full animate-wave"
                style={{
                  height: `${20 + Math.random() * 20}%`,
                  animationDelay: `${i * 0.1}s`,
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Status text */}
      <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-sm text-muted-foreground whitespace-nowrap">
        {getStatusText()}
      </span>
    </button>
  )
}
