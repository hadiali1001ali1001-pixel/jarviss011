'use client'

import { cn } from '@/lib/utils'

interface TranscriptDisplayProps {
  transcript: string
  interimTranscript?: string
  isListening?: boolean
  className?: string
}

export function TranscriptDisplay({
  transcript,
  interimTranscript = '',
  isListening = false,
  className,
}: TranscriptDisplayProps) {
  const hasContent = transcript || interimTranscript

  if (!hasContent && !isListening) {
    return null
  }

  return (
    <div
      className={cn(
        'glass-elevated rounded-lg px-6 py-4 max-w-2xl mx-auto',
        'transition-all duration-300',
        className,
      )}
    >
      <div className="flex items-start gap-3">
        {/* Microphone indicator */}
        <div className="flex-shrink-0 mt-1">
          <div
            className={cn(
              'w-2 h-2 rounded-full',
              isListening ? 'bg-cyan-400 animate-pulse' : 'bg-muted-foreground/50',
            )}
          />
        </div>

        {/* Transcript text */}
        <div className="flex-1 min-h-[24px]">
          {transcript && (
            <span className="text-foreground">{transcript}</span>
          )}
          {interimTranscript && (
            <span className="text-muted-foreground italic">
              {transcript ? ' ' : ''}{interimTranscript}
            </span>
          )}
          {isListening && !hasContent && (
            <span className="text-muted-foreground italic">
              Listening...
            </span>
          )}
          {/* Blinking cursor */}
          {isListening && (
            <span className="inline-block w-0.5 h-4 bg-cyan-400 ml-0.5 animate-pulse" />
          )}
        </div>
      </div>

      {/* Label */}
      <p className="text-xs text-muted-foreground mt-2 text-right">
        Your message
      </p>
    </div>
  )
}
