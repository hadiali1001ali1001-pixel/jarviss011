'use client'

import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Mic, Keyboard, RotateCcw, History, Settings } from 'lucide-react'

interface ControlBarProps {
  onMicClick: () => void
  onKeyboardClick: () => void
  onResetClick: () => void
  onHistoryClick: () => void
  onSettingsClick: () => void
  isListening: boolean
  className?: string
}

export function ControlBar({
  onMicClick,
  onKeyboardClick,
  onResetClick,
  onHistoryClick,
  onSettingsClick,
  isListening,
  className,
}: ControlBarProps) {
  return (
    <div
      className={cn(
        'flex items-center justify-center gap-2',
        className,
      )}
    >
      {/* History */}
      <Button
        variant="ghost"
        size="lg"
        onClick={onHistoryClick}
        className="h-12 w-12 rounded-full glass hover:glow-sm"
      >
        <History className="h-5 w-5" />
        <span className="sr-only">View history</span>
      </Button>

      {/* Reset */}
      <Button
        variant="ghost"
        size="lg"
        onClick={onResetClick}
        className="h-12 w-12 rounded-full glass hover:glow-sm"
      >
        <RotateCcw className="h-5 w-5" />
        <span className="sr-only">New conversation</span>
      </Button>

      {/* Main mic button */}
      <Button
        variant="default"
        size="lg"
        onClick={onMicClick}
        className={cn(
          'h-16 w-16 rounded-full',
          'bg-gradient-to-br from-cyan-500 to-teal-500',
          'hover:from-cyan-400 hover:to-teal-400',
          'shadow-lg transition-all duration-200',
          isListening && 'glow-lg scale-110',
        )}
      >
        <Mic className={cn('h-6 w-6', isListening && 'animate-pulse')} />
        <span className="sr-only">{isListening ? 'Stop listening' : 'Start listening'}</span>
      </Button>

      {/* Keyboard input */}
      <Button
        variant="ghost"
        size="lg"
        onClick={onKeyboardClick}
        className="h-12 w-12 rounded-full glass hover:glow-sm"
      >
        <Keyboard className="h-5 w-5" />
        <span className="sr-only">Type message</span>
      </Button>

      {/* Settings */}
      <Button
        variant="ghost"
        size="lg"
        onClick={onSettingsClick}
        className="h-12 w-12 rounded-full glass hover:glow-sm"
      >
        <Settings className="h-5 w-5" />
        <span className="sr-only">Settings</span>
      </Button>
    </div>
  )
}
