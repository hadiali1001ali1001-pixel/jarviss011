'use client'

import { cn } from '@/lib/utils'
import type { VoiceState } from '@/types/voice'
import { Wifi, WifiOff, Mic, MicOff } from 'lucide-react'

interface StatusIndicatorProps {
  voiceState: VoiceState
  isConnected?: boolean
  isMicEnabled?: boolean
  className?: string
}

export function StatusIndicator({
  voiceState,
  isConnected = true,
  isMicEnabled = true,
  className,
}: StatusIndicatorProps) {
  const getStateLabel = () => {
    switch (voiceState) {
      case 'idle':
        return 'Ready'
      case 'listening':
        return 'Listening'
      case 'processing':
        return 'Thinking'
      case 'speaking':
        return 'Speaking'
      case 'error':
        return 'Error'
      default:
        return 'Unknown'
    }
  }

  const getStateColor = () => {
    switch (voiceState) {
      case 'idle':
        return 'bg-muted-foreground'
      case 'listening':
        return 'bg-cyan-400 animate-pulse'
      case 'processing':
        return 'bg-yellow-400 animate-pulse'
      case 'speaking':
        return 'bg-emerald-400 animate-pulse'
      case 'error':
        return 'bg-red-500'
      default:
        return 'bg-muted-foreground'
    }
  }

  return (
    <div className={cn('flex items-center gap-4', className)}>
      {/* Voice state indicator */}
      <div className="flex items-center gap-2">
        <div className={cn('w-2 h-2 rounded-full', getStateColor())} />
        <span className="text-sm text-muted-foreground">{getStateLabel()}</span>
      </div>

      {/* Divider */}
      <div className="h-4 w-px bg-border" />

      {/* Connection status */}
      <div className="flex items-center gap-2">
        {isConnected ? (
          <Wifi className="w-4 h-4 text-emerald-400" />
        ) : (
          <WifiOff className="w-4 h-4 text-red-500" />
        )}
        <span className="text-sm text-muted-foreground">
          {isConnected ? 'Connected' : 'Offline'}
        </span>
      </div>

      {/* Divider */}
      <div className="h-4 w-px bg-border" />

      {/* Microphone status */}
      <div className="flex items-center gap-2">
        {isMicEnabled ? (
          <Mic className="w-4 h-4 text-cyan-400" />
        ) : (
          <MicOff className="w-4 h-4 text-red-500" />
        )}
        <span className="text-sm text-muted-foreground">
          {isMicEnabled ? 'Mic On' : 'Mic Off'}
        </span>
      </div>
    </div>
  )
}
