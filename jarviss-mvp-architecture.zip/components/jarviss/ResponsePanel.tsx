'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import { Volume2, VolumeX } from 'lucide-react'

interface ResponsePanelProps {
  response: string
  isStreaming?: boolean
  isSpeaking?: boolean
  onStopSpeaking?: () => void
  className?: string
}

export function ResponsePanel({
  response,
  isStreaming = false,
  isSpeaking = false,
  onStopSpeaking,
  className,
}: ResponsePanelProps) {
  const [displayedText, setDisplayedText] = useState('')
  const [isTypingComplete, setIsTypingComplete] = useState(false)

  // Typing effect
  useEffect(() => {
    if (!response) {
      setDisplayedText('')
      setIsTypingComplete(false)
      return
    }

    if (isStreaming) {
      // When streaming, show all text immediately
      setDisplayedText(response)
      setIsTypingComplete(false)
      return
    }

    // Typing animation for non-streaming responses
    let index = 0
    setIsTypingComplete(false)
    setDisplayedText('')

    const typingInterval = setInterval(() => {
      if (index < response.length) {
        setDisplayedText(response.slice(0, index + 1))
        index++
      } else {
        setIsTypingComplete(true)
        clearInterval(typingInterval)
      }
    }, 15) // Adjust speed here

    return () => clearInterval(typingInterval)
  }, [response, isStreaming])

  if (!response && !isStreaming) {
    return null
  }

  return (
    <div
      className={cn(
        'glass-elevated rounded-lg px-6 py-4 max-w-2xl mx-auto',
        'transition-all duration-300',
        className,
      )}
    >
      <div className="flex items-start gap-3">
        {/* Jarviss indicator */}
        <div className="flex-shrink-0 mt-1">
          <div
            className={cn(
              'w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-teal-500',
              'flex items-center justify-center text-xs font-bold text-white',
              'shadow-lg glow-sm',
            )}
          >
            J
          </div>
        </div>

        {/* Response text */}
        <div className="flex-1">
          <p className="text-foreground leading-relaxed whitespace-pre-wrap">
            {displayedText}
            {/* Cursor while typing or streaming */}
            {(!isTypingComplete || isStreaming) && (
              <span className="inline-block w-0.5 h-4 bg-cyan-400 ml-0.5 animate-pulse" />
            )}
          </p>

          {/* Speaking indicator */}
          {isSpeaking && (
            <button
              onClick={onStopSpeaking}
              className={cn(
                'mt-3 flex items-center gap-2 text-sm text-cyan-400',
                'hover:text-cyan-300 transition-colors',
              )}
            >
              <Volume2 className="w-4 h-4 animate-pulse" />
              <span>Speaking... (click to stop)</span>
            </button>
          )}
        </div>
      </div>

      {/* Label */}
      <div className="flex items-center justify-between mt-2">
        <p className="text-xs text-muted-foreground">Jarviss</p>
        {isSpeaking && onStopSpeaking && (
          <button
            onClick={onStopSpeaking}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
          >
            <VolumeX className="w-3 h-3" />
            Mute
          </button>
        )}
      </div>
    </div>
  )
}
