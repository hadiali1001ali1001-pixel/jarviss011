export type VoiceState = 
  | 'idle'       // Waiting for activation
  | 'listening'  // Recording user speech
  | 'processing' // STT + AI processing
  | 'speaking'   // TTS playback
  | 'error'      // Error state

export interface AudioConfig {
  sampleRate: number
  channelCount: number
  mimeType: string
}

export interface TranscriptionResult {
  text: string
  confidence: number
  isFinal: boolean
}

export interface VoiceSettings {
  voiceId: string
  voiceName: string
  wakeWordEnabled: boolean
  autoListen: boolean
  volume: number
}
