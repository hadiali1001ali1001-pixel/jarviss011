import { create } from 'zustand'
import type { VoiceState, VoiceSettings } from '@/types/voice'
import { DEFAULT_VOICE_SETTINGS } from '@/lib/constants'

interface VoiceStore {
  // State
  state: VoiceState
  transcript: string
  interimTranscript: string
  errorMessage: string | null
  settings: VoiceSettings
  
  // Audio levels for visualization
  audioLevel: number
  
  // Actions
  setState: (state: VoiceState) => void
  setTranscript: (transcript: string) => void
  setInterimTranscript: (transcript: string) => void
  setError: (message: string | null) => void
  setAudioLevel: (level: number) => void
  updateSettings: (settings: Partial<VoiceSettings>) => void
  reset: () => void
  
  // Lifecycle actions
  startListening: () => void
  stopListening: () => void
  startProcessing: () => void
  startSpeaking: () => void
  finishSpeaking: () => void
}

export const useVoiceStore = create<VoiceStore>((set) => ({
  // Initial state
  state: 'idle',
  transcript: '',
  interimTranscript: '',
  errorMessage: null,
  settings: DEFAULT_VOICE_SETTINGS,
  audioLevel: 0,
  
  // Basic setters
  setState: (state) => set({ state }),
  setTranscript: (transcript) => set({ transcript }),
  setInterimTranscript: (interimTranscript) => set({ interimTranscript }),
  setError: (errorMessage) => set({ errorMessage, state: errorMessage ? 'error' : 'idle' }),
  setAudioLevel: (audioLevel) => set({ audioLevel }),
  updateSettings: (newSettings) => 
    set((state) => ({ settings: { ...state.settings, ...newSettings } })),
  
  reset: () => set({
    state: 'idle',
    transcript: '',
    interimTranscript: '',
    errorMessage: null,
    audioLevel: 0,
  }),
  
  // Lifecycle actions
  startListening: () => set({
    state: 'listening',
    transcript: '',
    interimTranscript: '',
    errorMessage: null,
  }),
  
  stopListening: () => set({
    state: 'idle',
    interimTranscript: '',
  }),
  
  startProcessing: () => set({
    state: 'processing',
    interimTranscript: '',
  }),
  
  startSpeaking: () => set({
    state: 'speaking',
  }),
  
  finishSpeaking: () => set({
    state: 'idle',
  }),
}))
