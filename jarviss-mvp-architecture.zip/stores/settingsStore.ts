import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface SettingsStore {
  // UI Settings
  theme: 'dark' | 'light'
  showTranscript: boolean
  showHistory: boolean
  particlesEnabled: boolean
  
  // API Keys (for self-hosting)
  openaiApiKey: string | null
  elevenLabsApiKey: string | null
  
  // Actions
  setTheme: (theme: 'dark' | 'light') => void
  toggleTranscript: () => void
  toggleHistory: () => void
  toggleParticles: () => void
  setOpenAIKey: (key: string | null) => void
  setElevenLabsKey: (key: string | null) => void
  resetSettings: () => void
}

const defaultSettings = {
  theme: 'dark' as const,
  showTranscript: true,
  showHistory: false,
  particlesEnabled: true,
  openaiApiKey: null,
  elevenLabsApiKey: null,
}

export const useSettingsStore = create<SettingsStore>()(
  persist(
    (set) => ({
      ...defaultSettings,
      
      setTheme: (theme) => set({ theme }),
      toggleTranscript: () => set((state) => ({ showTranscript: !state.showTranscript })),
      toggleHistory: () => set((state) => ({ showHistory: !state.showHistory })),
      toggleParticles: () => set((state) => ({ particlesEnabled: !state.particlesEnabled })),
      setOpenAIKey: (openaiApiKey) => set({ openaiApiKey }),
      setElevenLabsKey: (elevenLabsApiKey) => set({ elevenLabsApiKey }),
      resetSettings: () => set(defaultSettings),
    }),
    {
      name: 'jarviss-settings',
    }
  )
)
