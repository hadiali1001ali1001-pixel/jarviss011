import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Message, Conversation, ChatSettings } from '@/types/chat'
import { DEFAULT_CHAT_SETTINGS } from '@/lib/constants'

interface ConversationStore {
  // Current conversation
  currentConversation: Conversation | null
  messages: Message[]
  isLoading: boolean
  
  // History
  conversations: Conversation[]
  
  // Settings
  settings: ChatSettings
  
  // Actions
  addMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void
  updateMessage: (id: string, content: string) => void
  clearMessages: () => void
  setLoading: (loading: boolean) => void
  
  // Conversation management
  createConversation: () => void
  loadConversation: (id: string) => void
  deleteConversation: (id: string) => void
  saveCurrentConversation: () => void
  
  // Settings
  updateSettings: (settings: Partial<ChatSettings>) => void
}

const generateId = () => Math.random().toString(36).substring(2, 15)

export const useConversationStore = create<ConversationStore>()(
  persist(
    (set, get) => ({
      // Initial state
      currentConversation: null,
      messages: [],
      isLoading: false,
      conversations: [],
      settings: DEFAULT_CHAT_SETTINGS,
      
      // Message actions
      addMessage: (message) => {
        const newMessage: Message = {
          ...message,
          id: generateId(),
          timestamp: Date.now(),
        }
        set((state) => ({
          messages: [...state.messages, newMessage],
        }))
      },
      
      updateMessage: (id, content) => {
        set((state) => ({
          messages: state.messages.map((msg) =>
            msg.id === id ? { ...msg, content } : msg
          ),
        }))
      },
      
      clearMessages: () => set({ messages: [], currentConversation: null }),
      
      setLoading: (isLoading) => set({ isLoading }),
      
      // Conversation management
      createConversation: () => {
        const { messages, conversations } = get()
        
        // Save current conversation if it has messages
        if (messages.length > 0) {
          const currentConv = get().currentConversation
          if (currentConv) {
            const updatedConv = {
              ...currentConv,
              messages,
              updatedAt: Date.now(),
            }
            set((state) => ({
              conversations: state.conversations.map((c) =>
                c.id === currentConv.id ? updatedConv : c
              ),
            }))
          }
        }
        
        // Create new conversation
        const newConversation: Conversation = {
          id: generateId(),
          title: 'New Conversation',
          messages: [],
          createdAt: Date.now(),
          updatedAt: Date.now(),
        }
        
        set({
          currentConversation: newConversation,
          messages: [],
          conversations: [newConversation, ...conversations],
        })
      },
      
      loadConversation: (id) => {
        const { conversations } = get()
        const conversation = conversations.find((c) => c.id === id)
        if (conversation) {
          set({
            currentConversation: conversation,
            messages: conversation.messages,
          })
        }
      },
      
      deleteConversation: (id) => {
        set((state) => ({
          conversations: state.conversations.filter((c) => c.id !== id),
          ...(state.currentConversation?.id === id
            ? { currentConversation: null, messages: [] }
            : {}),
        }))
      },
      
      saveCurrentConversation: () => {
        const { currentConversation, messages, conversations } = get()
        
        if (!currentConversation) {
          // Create new conversation
          const title = messages[0]?.content.slice(0, 50) || 'New Conversation'
          const newConversation: Conversation = {
            id: generateId(),
            title,
            messages,
            createdAt: Date.now(),
            updatedAt: Date.now(),
          }
          set({
            currentConversation: newConversation,
            conversations: [newConversation, ...conversations],
          })
        } else {
          // Update existing conversation
          const title = messages[0]?.content.slice(0, 50) || currentConversation.title
          const updatedConv = {
            ...currentConversation,
            title,
            messages,
            updatedAt: Date.now(),
          }
          set((state) => ({
            currentConversation: updatedConv,
            conversations: state.conversations.map((c) =>
              c.id === currentConversation.id ? updatedConv : c
            ),
          }))
        }
      },
      
      updateSettings: (newSettings) =>
        set((state) => ({ settings: { ...state.settings, ...newSettings } })),
    }),
    {
      name: 'jarviss-conversations',
      partialize: (state) => ({
        conversations: state.conversations,
        settings: state.settings,
      }),
    }
  )
)
