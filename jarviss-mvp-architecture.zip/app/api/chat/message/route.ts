import { streamText } from 'ai'
import { JARVISS_SYSTEM_PROMPT } from '@/lib/constants'
import type { Message } from '@/types/chat'

export const maxDuration = 30

export async function POST(req: Request) {
  try {
    const { message, history = [] }: { message: string; history: Message[] } = await req.json()

    if (!message?.trim()) {
      return new Response('Message is required', { status: 400 })
    }

    // Convert history to model messages format
    const historyMessages = history.map((msg) => ({
      role: msg.role as 'user' | 'assistant',
      content: msg.content,
    }))

    // Add the new user message
    const messages = [
      ...historyMessages,
      { role: 'user' as const, content: message },
    ]

    // Check for API key - if not available, use fallback response
    const hasApiKey = process.env.OPENAI_API_KEY

    if (!hasApiKey) {
      // Provide a smart fallback response without API key
      const fallbackResponse = generateFallbackResponse(message)
      
      // Stream the fallback response character by character
      const encoder = new TextEncoder()
      const stream = new ReadableStream({
        async start(controller) {
          for (const char of fallbackResponse) {
            controller.enqueue(encoder.encode(char))
            await new Promise(resolve => setTimeout(resolve, 15))
          }
          controller.close()
        },
      })

      return new Response(stream, {
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          'Transfer-Encoding': 'chunked',
        },
      })
    }

    // Use OpenAI with AI SDK
    const result = streamText({
      model: 'openai/gpt-4o',
      system: JARVISS_SYSTEM_PROMPT,
      messages,
      abortSignal: req.signal,
      maxOutputTokens: 1024,
    })

    // Return streaming text response
    return result.toTextStreamResponse()

  } catch (error) {
    console.error('Chat API error:', error)
    return new Response('Internal server error', { status: 500 })
  }
}

// Fallback responses when no API key is configured
function generateFallbackResponse(message: string): string {
  const lowerMessage = message.toLowerCase()

  // Greeting responses
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
    return "Hello! I'm Jarviss, your AI assistant. I'm currently running in demo mode without an OpenAI API key. To unlock my full potential, please configure your OPENAI_API_KEY in the environment variables. How can I help you today?"
  }

  // Help/capabilities
  if (lowerMessage.includes('help') || lowerMessage.includes('what can you do') || lowerMessage.includes('capabilities')) {
    return "I'm Jarviss, an AI voice assistant inspired by Iron Man's JARVIS. In demo mode, I can respond to basic queries, but my full capabilities require an OpenAI API key. Once configured, I can help with coding questions, general knowledge, creative writing, analysis, and much more. Would you like instructions on setting up the API key?"
  }

  // Time/date
  if (lowerMessage.includes('time') || lowerMessage.includes('date')) {
    const now = new Date()
    return `The current date and time is ${now.toLocaleString()}. I'm here and ready to assist you, though I'm running in demo mode. Configure an OpenAI API key to unlock my full capabilities.`
  }

  // Weather
  if (lowerMessage.includes('weather')) {
    return "I apologize, but I'm currently unable to check the weather as I'm running in demo mode without external API access. To enable weather lookups and other advanced features, please configure your OPENAI_API_KEY in the environment settings."
  }

  // Name query
  if (lowerMessage.includes('your name') || lowerMessage.includes('who are you')) {
    return "I am Jarviss, your personal AI assistant. My name is a tribute to the legendary JARVIS from Iron Man. I'm designed to be intelligent, articulate, and helpful. Currently running in demo mode - configure an OpenAI API key to experience my full capabilities."
  }

  // Thank you
  if (lowerMessage.includes('thank')) {
    return "You're welcome! It's my pleasure to assist. If you need anything else, I'm here. Remember, configuring an OpenAI API key will significantly enhance my abilities to help you."
  }

  // Default fallback
  const responses = [
    `I understand you're asking about "${message.slice(0, 50)}${message.length > 50 ? '...' : ''}". I'm currently running in demo mode without an OpenAI API key configured. To provide you with accurate, detailed responses, please set up your OPENAI_API_KEY in the environment variables. Is there anything basic I can help you with in the meantime?`,
    `That's an interesting question! Unfortunately, I'm running in demo mode and can't provide a comprehensive answer without my AI backend. Configure an OpenAI API key to unlock my full potential and get detailed responses to questions like this.`,
    `I appreciate your question. In demo mode, my responses are limited. With an OpenAI API key configured, I could provide you with detailed, intelligent responses. Would you like help setting that up?`,
  ]

  return responses[Math.floor(Math.random() * responses.length)]
}
