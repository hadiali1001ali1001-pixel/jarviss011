import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { text, voiceId = 'default' } = await req.json()

    if (!text?.trim()) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 })
    }

    // Check for ElevenLabs API key
    const apiKey = process.env.ELEVENLABS_API_KEY

    if (!apiKey) {
      // Return a message suggesting to use browser TTS
      return NextResponse.json({
        error: 'ElevenLabs API key not configured. Please use browser speech synthesis instead.',
        useBrowserTTS: true,
      })
    }

    // ElevenLabs voice IDs
    const voiceMap: Record<string, string> = {
      default: '21m00Tcm4TlvDq8ikWAM', // Rachel
      male: 'VR6AewLTigWG4xSOukaG', // Arnold
      female: '21m00Tcm4TlvDq8ikWAM', // Rachel
      british: 'IKne3meq5aSn9XLyUdCD', // Charlie
    }

    const elevenLabsVoiceId = voiceMap[voiceId] || voiceMap.default

    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${elevenLabsVoiceId}/stream`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'xi-api-key': apiKey,
        },
        body: JSON.stringify({
          text,
          model_id: 'eleven_monolingual_v1',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75,
          },
        }),
      }
    )

    if (!response.ok) {
      const error = await response.text()
      console.error('ElevenLabs API error:', error)
      return NextResponse.json({ error: 'Speech synthesis failed' }, { status: 500 })
    }

    // Stream the audio response
    const audioStream = response.body

    if (!audioStream) {
      return NextResponse.json({ error: 'No audio stream' }, { status: 500 })
    }

    return new NextResponse(audioStream, {
      headers: {
        'Content-Type': 'audio/mpeg',
        'Transfer-Encoding': 'chunked',
      },
    })

  } catch (error) {
    console.error('TTS error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
