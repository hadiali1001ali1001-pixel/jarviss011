import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()
    const audio = formData.get('audio') as Blob | null

    if (!audio) {
      return NextResponse.json({ error: 'No audio file provided' }, { status: 400 })
    }

    // Check for OpenAI API key for Whisper
    const apiKey = process.env.OPENAI_API_KEY

    if (!apiKey) {
      // Return a message suggesting to use browser STT
      return NextResponse.json({
        text: '',
        error: 'OpenAI API key not configured. Please use browser speech recognition instead.',
        useBrowserSTT: true,
      })
    }

    // Convert blob to form data for OpenAI
    const openaiFormData = new FormData()
    openaiFormData.append('file', audio, 'audio.webm')
    openaiFormData.append('model', 'whisper-1')
    openaiFormData.append('language', 'en')

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
      body: openaiFormData,
    })

    if (!response.ok) {
      const error = await response.text()
      console.error('Whisper API error:', error)
      return NextResponse.json({ error: 'Transcription failed' }, { status: 500 })
    }

    const data = await response.json()

    return NextResponse.json({
      text: data.text,
      confidence: 1.0, // Whisper doesn't return confidence scores
    })

  } catch (error) {
    console.error('Transcription error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
