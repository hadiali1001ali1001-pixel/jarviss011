'use client'

import { useRouter } from 'next/navigation'
import { ArrowLeft, Sparkles, Volume2, Eye, Key, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useSettingsStore } from '@/stores/settingsStore'
import { useVoiceStore } from '@/stores/voiceStore'
import { useConversationStore } from '@/stores/conversationStore'
import { cn } from '@/lib/utils'

export default function SettingsPage() {
  const router = useRouter()

  // Settings store
  const particlesEnabled = useSettingsStore((s) => s.particlesEnabled)
  const showTranscript = useSettingsStore((s) => s.showTranscript)
  const toggleParticles = useSettingsStore((s) => s.toggleParticles)
  const toggleTranscript = useSettingsStore((s) => s.toggleTranscript)
  const openaiApiKey = useSettingsStore((s) => s.openaiApiKey)
  const elevenLabsApiKey = useSettingsStore((s) => s.elevenLabsApiKey)
  const setOpenAIKey = useSettingsStore((s) => s.setOpenAIKey)
  const setElevenLabsKey = useSettingsStore((s) => s.setElevenLabsKey)
  const resetSettings = useSettingsStore((s) => s.resetSettings)

  // Voice settings
  const voiceSettings = useVoiceStore((s) => s.settings)
  const updateVoiceSettings = useVoiceStore((s) => s.updateSettings)

  // Conversation settings
  const chatSettings = useConversationStore((s) => s.settings)
  const updateChatSettings = useConversationStore((s) => s.updateSettings)

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push('/')}
            className="h-9 w-9 p-0"
          >
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </Button>
          <div>
            <h1 className="text-xl font-bold text-foreground">Settings</h1>
            <p className="text-sm text-muted-foreground">Configure Jarviss</p>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-8 space-y-8">
        {/* Visual Settings */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Eye className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Visual Settings</h2>
          </div>
          <div className="glass-elevated rounded-lg p-4 space-y-4">
            <SettingRow
              label="Particle Background"
              description="Show floating particles in the background"
            >
              <Switch
                checked={particlesEnabled}
                onCheckedChange={toggleParticles}
              />
            </SettingRow>
            <SettingRow
              label="Show Transcript"
              description="Display your speech as text while speaking"
            >
              <Switch
                checked={showTranscript}
                onCheckedChange={toggleTranscript}
              />
            </SettingRow>
          </div>
        </section>

        {/* Voice Settings */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Volume2 className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Voice Settings</h2>
          </div>
          <div className="glass-elevated rounded-lg p-4 space-y-4">
            <SettingRow
              label="Wake Word Detection"
              description="Activate by saying 'Jarviss'"
            >
              <Switch
                checked={voiceSettings.wakeWordEnabled}
                onCheckedChange={(checked) =>
                  updateVoiceSettings({ wakeWordEnabled: checked })
                }
              />
            </SettingRow>
            <SettingRow
              label="Auto-Listen After Response"
              description="Automatically start listening after Jarviss finishes speaking"
            >
              <Switch
                checked={voiceSettings.autoListen}
                onCheckedChange={(checked) =>
                  updateVoiceSettings({ autoListen: checked })
                }
              />
            </SettingRow>
            <div className="space-y-2">
              <Label>Volume</Label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={voiceSettings.volume}
                onChange={(e) =>
                  updateVoiceSettings({ volume: parseFloat(e.target.value) })
                }
                className="w-full accent-primary"
              />
              <p className="text-xs text-muted-foreground">
                {Math.round(voiceSettings.volume * 100)}%
              </p>
            </div>
          </div>
        </section>

        {/* AI Settings */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">AI Settings</h2>
          </div>
          <div className="glass-elevated rounded-lg p-4 space-y-4">
            <div className="space-y-2">
              <Label>AI Model</Label>
              <select
                value={chatSettings.aiModel}
                onChange={(e) => updateChatSettings({ aiModel: e.target.value })}
                className={cn(
                  'w-full h-9 rounded-md border border-input bg-background px-3',
                  'text-sm focus:outline-none focus:ring-2 focus:ring-ring'
                )}
              >
                <option value="gpt-4o">GPT-4o (Recommended)</option>
                <option value="gpt-4o-mini">GPT-4o Mini (Faster)</option>
                <option value="gpt-4-turbo">GPT-4 Turbo</option>
              </select>
              <p className="text-xs text-muted-foreground">
                Select the AI model for responses
              </p>
            </div>
            <div className="space-y-2">
              <Label>Temperature</Label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={chatSettings.temperature}
                onChange={(e) =>
                  updateChatSettings({ temperature: parseFloat(e.target.value) })
                }
                className="w-full accent-primary"
              />
              <p className="text-xs text-muted-foreground">
                {chatSettings.temperature} - {chatSettings.temperature < 0.3 ? 'More focused' : chatSettings.temperature > 0.7 ? 'More creative' : 'Balanced'}
              </p>
            </div>
          </div>
        </section>

        {/* API Keys */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Key className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">API Keys (Optional)</h2>
          </div>
          <div className="glass-elevated rounded-lg p-4 space-y-4">
            <p className="text-sm text-muted-foreground">
              Configure API keys for enhanced functionality. Without these, Jarviss
              will use browser-based alternatives.
            </p>
            <div className="space-y-2">
              <Label htmlFor="openai-key">OpenAI API Key</Label>
              <Input
                id="openai-key"
                type="password"
                placeholder="sk-..."
                value={openaiApiKey || ''}
                onChange={(e) => setOpenAIKey(e.target.value || null)}
              />
              <p className="text-xs text-muted-foreground">
                Required for GPT-4o responses and Whisper transcription
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="elevenlabs-key">ElevenLabs API Key</Label>
              <Input
                id="elevenlabs-key"
                type="password"
                placeholder="Your ElevenLabs API key"
                value={elevenLabsApiKey || ''}
                onChange={(e) => setElevenLabsKey(e.target.value || null)}
              />
              <p className="text-xs text-muted-foreground">
                Required for high-quality voice synthesis
              </p>
            </div>
          </div>
        </section>

        {/* Reset */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <RotateCcw className="h-5 w-5 text-destructive" />
            <h2 className="text-lg font-semibold">Reset</h2>
          </div>
          <div className="glass-elevated rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Reset All Settings</p>
                <p className="text-sm text-muted-foreground">
                  Restore default settings (API keys will be cleared)
                </p>
              </div>
              <Button
                variant="destructive"
                onClick={() => {
                  if (confirm('Are you sure you want to reset all settings?')) {
                    resetSettings()
                  }
                }}
              >
                Reset
              </Button>
            </div>
          </div>
        </section>
      </div>
    </main>
  )
}

function SettingRow({
  label,
  description,
  children,
}: {
  label: string
  description: string
  children: React.ReactNode
}) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <p className="font-medium">{label}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      {children}
    </div>
  )
}
