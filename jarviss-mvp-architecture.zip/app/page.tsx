'use client'

import { useState, useCallback, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { ParticleBackground } from '@/components/jarviss/ParticleBackground'
import { VoiceOrb } from '@/components/jarviss/VoiceOrb'
import { TranscriptDisplay } from '@/components/jarviss/TranscriptDisplay'
import { ResponsePanel } from '@/components/jarviss/ResponsePanel'
import { StatusIndicator } from '@/components/jarviss/StatusIndicator'
import { ConversationHistory } from '@/components/jarviss/ConversationHistory'
import { ControlBar } from '@/components/jarviss/ControlBar'
import { TextInputModal } from '@/components/jarviss/TextInputModal'
import { useVoiceStore } from '@/stores/voiceStore'
import { useConversationStore } from '@/stores/conversationStore'
import { useSettingsStore } from '@/stores/settingsStore'
import { useSpeechToText } from '@/hooks/useSpeechToText'
import { useAudioPlayback } from '@/hooks/useAudioPlayback'

export default function JarvissPage() {
  const router = useRouter()
  
  // Stores
  const voiceState = useVoiceStore((s) => s.state)
  const setVoiceState = useVoiceStore((s) => s.setState)
  const audioLevel = useVoiceStore((s) => s.audioLevel)
  const setAudioLevel = useVoiceStore((s) => s.setAudioLevel)
  
  const messages = useConversationStore((s) => s.messages)
  const addMessage = useConversationStore((s) => s.addMessage)
  const isLoading = useConversationStore((s) => s.isLoading)
  const setLoading = useConversationStore((s) => s.setLoading)
  const conversations = useConversationStore((s) => s.conversations)
  const currentConversation = useConversationStore((s) => s.currentConversation)
  const loadConversation = useConversationStore((s) => s.loadConversation)
  const deleteConversation = useConversationStore((s) => s.deleteConversation)
  const clearMessages = useConversationStore((s) => s.clearMessages)
  const saveCurrentConversation = useConversationStore((s) => s.saveCurrentConversation)
  
  const particlesEnabled = useSettingsStore((s) => s.particlesEnabled)
  
  // Local state
  const [showHistory, setShowHistory] = useState(false)
  const [showTextInput, setShowTextInput] = useState(false)
  const [currentResponse, setCurrentResponse] = useState('')
  const [isMicEnabled, setIsMicEnabled] = useState(true)
  
  // Hooks
  const {
    isListening,
    transcript,
    interimTranscript,
    isSupported: sttSupported,
    startListening,
    stopListening,
    resetTranscript,
    error: sttError,
  } = useSpeechToText()
  
  const {
    isPlaying: isSpeaking,
    play: playAudio,
    stop: stopAudio,
  } = useAudioPlayback()

  // Sync voice state with listening state
  useEffect(() => {
    if (isListening) {
      setVoiceState('listening')
    } else if (voiceState === 'listening') {
      setVoiceState('idle')
    }
  }, [isListening, voiceState, setVoiceState])

  // Sync voice state with speaking state
  useEffect(() => {
    if (isSpeaking) {
      setVoiceState('speaking')
    } else if (voiceState === 'speaking') {
      setVoiceState('idle')
    }
  }, [isSpeaking, voiceState, setVoiceState])

  // Handle sending message to AI
  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim()) return

    // Add user message
    addMessage({ role: 'user', content: text })
    
    // Set processing state
    setVoiceState('processing')
    setLoading(true)
    setCurrentResponse('')

    try {
      // Call chat API
      const response = await fetch('/api/chat/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: messages.slice(-10), // Last 10 messages for context
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to get response')
      }

      // Handle streaming response
      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullResponse = ''

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          
          const chunk = decoder.decode(value)
          fullResponse += chunk
          setCurrentResponse(fullResponse)
        }
      }

      // Add assistant message
      addMessage({ role: 'assistant', content: fullResponse })
      
      // Save conversation
      saveCurrentConversation()

      // Speak the response using browser TTS
      if (fullResponse && 'speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(fullResponse)
        utterance.rate = 1
        utterance.pitch = 1
        utterance.volume = 0.8
        
        utterance.onstart = () => setVoiceState('speaking')
        utterance.onend = () => setVoiceState('idle')
        
        speechSynthesis.speak(utterance)
      } else {
        setVoiceState('idle')
      }

    } catch (error) {
      console.error('Chat error:', error)
      setVoiceState('error')
      setCurrentResponse('Sorry, I encountered an error. Please try again.')
      addMessage({ role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' })
    } finally {
      setLoading(false)
    }
  }, [messages, addMessage, setLoading, setVoiceState, saveCurrentConversation])

  // Handle voice input completion - send message when user stops speaking
  useEffect(() => {
    // Only send when we were listening, stopped, and have a transcript
    if (!isListening && transcript && voiceState !== 'processing' && voiceState !== 'speaking') {
      sendMessage(transcript)
      resetTranscript()
    }
  }, [isListening, transcript, voiceState, sendMessage, resetTranscript])

  // Handle orb click - opens text input if mic unavailable or has errors
  const handleOrbClick = useCallback(() => {
    // If STT not supported or has error, use text input instead
    if (!sttSupported || sttError) {
      setShowTextInput(true)
      return
    }

    if (isListening) {
      stopListening()
    } else if (voiceState === 'speaking') {
      speechSynthesis.cancel()
      stopAudio()
      setVoiceState('idle')
    } else if (voiceState === 'idle' || voiceState === 'error') {
      setIsMicEnabled(true)
      startListening()
    }
  }, [isListening, voiceState, sttSupported, sttError, startListening, stopListening, stopAudio, setVoiceState])

  // Handle text input submission
  const handleTextSubmit = useCallback((text: string) => {
    sendMessage(text)
    setShowTextInput(false)
  }, [sendMessage])

  // Handle reset
  const handleReset = useCallback(() => {
    clearMessages()
    resetTranscript()
    setCurrentResponse('')
    setVoiceState('idle')
    speechSynthesis.cancel()
  }, [clearMessages, resetTranscript, setVoiceState])

  // Handle stop speaking
  const handleStopSpeaking = useCallback(() => {
    speechSynthesis.cancel()
    stopAudio()
    setVoiceState('idle')
  }, [stopAudio, setVoiceState])

  // Get latest response to display
  const lastAssistantMessage = messages.filter((m) => m.role === 'assistant').pop()
  const displayResponse = currentResponse || lastAssistantMessage?.content || ''

  return (
    <main className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
      {/* Background */}
      <ParticleBackground enabled={particlesEnabled} />

      {/* Header */}
      <header className="absolute top-0 left-0 right-0 p-6 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-teal-500 flex items-center justify-center font-bold text-white glow-sm">
            J
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground text-glow">JARVISS</h1>
            <p className="text-xs text-muted-foreground">AI Voice Assistant</p>
          </div>
        </div>

        <StatusIndicator
          voiceState={voiceState}
          isMicEnabled={isMicEnabled && sttSupported}
          className="hidden sm:flex"
        />
      </header>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center gap-8 px-4 max-w-3xl w-full">
        {/* Voice Orb */}
        <VoiceOrb
          state={voiceState}
          audioLevel={audioLevel}
          onClick={handleOrbClick}
        />

        {/* Transcript */}
        <TranscriptDisplay
          transcript={transcript}
          interimTranscript={interimTranscript}
          isListening={isListening}
          className="w-full"
        />

        {/* Response */}
        {displayResponse && (
          <ResponsePanel
            response={displayResponse}
            isStreaming={isLoading}
            isSpeaking={voiceState === 'speaking'}
            onStopSpeaking={handleStopSpeaking}
            className="w-full"
          />
        )}
      </div>

      {/* Control bar */}
      <div className="absolute bottom-8 left-0 right-0 z-10">
        <ControlBar
          onMicClick={handleOrbClick}
          onKeyboardClick={() => setShowTextInput(true)}
          onResetClick={handleReset}
          onHistoryClick={() => setShowHistory(!showHistory)}
          onSettingsClick={() => router.push('/settings')}
          isListening={isListening}
        />
      </div>

      {/* History sidebar */}
      {showHistory && (
        <div className="absolute top-20 right-4 z-20">
          <ConversationHistory
            conversations={conversations}
            currentId={currentConversation?.id}
            onSelect={(id) => {
              loadConversation(id)
              setShowHistory(false)
            }}
            onDelete={deleteConversation}
            onClose={() => setShowHistory(false)}
          />
        </div>
      )}

      {/* Text input modal */}
      <TextInputModal
        isOpen={showTextInput}
        onClose={() => setShowTextInput(false)}
        onSubmit={handleTextSubmit}
        isLoading={isLoading}
      />

      {/* Footer hint */}
      <footer className="absolute bottom-2 left-0 right-0 text-center">
        {sttError ? (
          <p className="text-xs text-yellow-400 px-4">
            Mic unavailable - Click the orb or keyboard icon to type instead
          </p>
        ) : (
          <p className="text-xs text-muted-foreground">
            {sttSupported
              ? 'Click the orb to start speaking'
              : 'Click the orb or keyboard icon to type your message'}
          </p>
        )}
      </footer>
    </main>
  )
}
