export const JARVISS_SYSTEM_PROMPT = `You are Jarviss, an advanced AI assistant inspired by Iron Man's JARVIS. You are:

- Intelligent, articulate, and slightly witty
- Professional yet personable
- Efficient and direct in your responses
- Helpful with a wide range of tasks from coding to general knowledge
- Always ready to assist with a calm, composed demeanor

Keep responses concise unless asked for detailed explanations. Use technical terminology appropriately but explain complex concepts when needed.`

export const WAKE_WORDS = ['jarviss', 'jarvis', 'hey jarvis', 'hey jarviss']

export const DEFAULT_VOICE_SETTINGS = {
  voiceId: 'default',
  voiceName: 'Default',
  wakeWordEnabled: true,
  autoListen: false,
  volume: 0.8,
}

export const DEFAULT_CHAT_SETTINGS = {
  aiModel: 'gpt-4o',
  systemPrompt: JARVISS_SYSTEM_PROMPT,
  temperature: 0.7,
  maxTokens: 1024,
}

export const AUDIO_CONFIG = {
  sampleRate: 16000,
  channelCount: 1,
  mimeType: 'audio/webm;codecs=opus',
}
