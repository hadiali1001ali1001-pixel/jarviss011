'use client'

import { useCallback, useRef, useState } from 'react'

interface UseAudioPlaybackReturn {
  isPlaying: boolean
  currentTime: number
  duration: number
  volume: number
  play: (source: string | Blob) => Promise<void>
  pause: () => void
  stop: () => void
  setVolume: (volume: number) => void
  error: string | null
}

export function useAudioPlayback(): UseAudioPlaybackReturn {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolumeState] = useState(0.8)
  const [error, setError] = useState<string | null>(null)
  
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  const cleanupAudio = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.src = ''
      audioRef.current = null
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
    setIsPlaying(false)
    setCurrentTime(0)
    setDuration(0)
  }, [])

  const play = useCallback(async (source: string | Blob) => {
    try {
      setError(null)
      cleanupAudio()
      
      const audio = new Audio()
      audioRef.current = audio
      
      // Set source
      if (source instanceof Blob) {
        audio.src = URL.createObjectURL(source)
      } else {
        audio.src = source
      }
      
      audio.volume = volume
      
      // Set up event listeners
      audio.onloadedmetadata = () => {
        setDuration(audio.duration)
      }
      
      audio.onended = () => {
        cleanupAudio()
      }
      
      audio.onerror = () => {
        setError('Failed to play audio')
        cleanupAudio()
      }
      
      // Start playing
      await audio.play()
      setIsPlaying(true)
      
      // Update current time
      intervalRef.current = setInterval(() => {
        if (audioRef.current) {
          setCurrentTime(audioRef.current.currentTime)
        }
      }, 100)
      
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to play audio'
      setError(message)
      cleanupAudio()
    }
  }, [volume, cleanupAudio])

  const pause = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause()
      setIsPlaying(false)
    }
  }, [])

  const stop = useCallback(() => {
    cleanupAudio()
  }, [cleanupAudio])

  const setVolume = useCallback((newVolume: number) => {
    const clampedVolume = Math.max(0, Math.min(1, newVolume))
    setVolumeState(clampedVolume)
    if (audioRef.current) {
      audioRef.current.volume = clampedVolume
    }
  }, [])

  return {
    isPlaying,
    currentTime,
    duration,
    volume,
    play,
    pause,
    stop,
    setVolume,
    error,
  }
}
