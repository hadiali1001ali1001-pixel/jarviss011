'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { WAKE_WORDS } from '@/lib/constants'

interface UseWakeWordReturn {
  isListening: boolean
  isSupported: boolean
  startListening: () => void
  stopListening: () => void
  error: string | null
}

export function useWakeWord(
  onWakeWord: () => void,
  enabled: boolean = true
): UseWakeWordReturn {
  const [isListening, setIsListening] = useState(false)
  const [isSupported, setIsSupported] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const restartTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    // Check for Web Speech API support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    setIsSupported(!!SpeechRecognition)
    
    if (!SpeechRecognition) {
      setError('Speech recognition is not supported in this browser')
      return
    }
    
    const recognition = new SpeechRecognition()
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = 'en-US'
    
    recognition.onresult = (event) => {
      const last = event.results.length - 1
      const transcript = event.results[last][0].transcript.toLowerCase().trim()
      
      // Check if transcript contains wake word
      const hasWakeWord = WAKE_WORDS.some((word) => 
        transcript.includes(word)
      )
      
      if (hasWakeWord) {
        onWakeWord()
        // Briefly pause to avoid re-triggering
        recognition.stop()
        setTimeout(() => {
          if (enabled && recognitionRef.current) {
            try {
              recognitionRef.current.start()
            } catch {
              // Already started
            }
          }
        }, 2000)
      }
    }
    
    recognition.onerror = (event) => {
      if (event.error === 'no-speech' || event.error === 'aborted') {
        // These are expected, restart listening
        return
      }
      setError(`Speech recognition error: ${event.error}`)
    }
    
    recognition.onend = () => {
      // Auto-restart if still enabled
      if (enabled && isListening) {
        restartTimeoutRef.current = setTimeout(() => {
          try {
            recognition.start()
          } catch {
            // Already started
          }
        }, 100)
      }
    }
    
    recognitionRef.current = recognition
    
    return () => {
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current)
      }
      recognition.stop()
    }
  }, [onWakeWord, enabled, isListening])

  const startListening = useCallback(() => {
    if (!recognitionRef.current || !isSupported) return
    
    setError(null)
    setIsListening(true)
    
    try {
      recognitionRef.current.start()
    } catch {
      // Already started
    }
  }, [isSupported])

  const stopListening = useCallback(() => {
    setIsListening(false)
    
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current)
    }
    
    if (recognitionRef.current) {
      recognitionRef.current.stop()
    }
  }, [])

  return {
    isListening,
    isSupported,
    startListening,
    stopListening,
    error,
  }
}

// TypeScript declarations for Web Speech API
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition
    webkitSpeechRecognition: typeof SpeechRecognition
  }
}
