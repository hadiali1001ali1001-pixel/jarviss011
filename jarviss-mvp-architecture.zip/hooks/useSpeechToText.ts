'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

// Declare SpeechRecognition types for TypeScript
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition
    webkitSpeechRecognition: typeof SpeechRecognition
  }
}

interface UseSpeechToTextReturn {
  isListening: boolean
  transcript: string
  interimTranscript: string
  isSupported: boolean
  startListening: () => void
  stopListening: () => void
  resetTranscript: () => void
  error: string | null
}

export function useSpeechToText(): UseSpeechToTextReturn {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [interimTranscript, setInterimTranscript] = useState('')
  const [isSupported, setIsSupported] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const finalTranscriptRef = useRef('')

  useEffect(() => {
    // Check for SpeechRecognition support
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition
    
    setIsSupported(!!SpeechRecognitionAPI)
    
    if (!SpeechRecognitionAPI) {
      setError('Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.')
      return
    }
    
    const recognition = new SpeechRecognitionAPI()
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = 'en-US'
    
    recognition.onstart = () => {
      // Recognition started
    }
    
    recognition.onresult = (event) => {
      let interimText = ''
      let finalText = finalTranscriptRef.current
      
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i]
        if (result.isFinal) {
          finalText += result[0].transcript + ' '
        } else {
          interimText += result[0].transcript
        }
      }
      
      finalTranscriptRef.current = finalText
      setTranscript(finalText.trim())
      setInterimTranscript(interimText)
    }
    
    recognition.onerror = (event) => {
      if (event.error === 'no-speech') {
        return
      }
      if (event.error === 'aborted') {
        return
      }
      if (event.error === 'not-allowed') {
        setError('Microphone permission denied. Please allow microphone access.')
        setIsListening(false)
        return
      }
      setError(`Speech recognition error: ${event.error}`)
      setIsListening(false)
    }
    
    recognition.onend = () => {
      setIsListening(false)
      setInterimTranscript('')
    }
    
    recognitionRef.current = recognition
    
    return () => {
      recognition.stop()
    }
  }, [])

  const startListening = useCallback(async () => {
    if (!recognitionRef.current || !isSupported) {
      return
    }
    
    // Request microphone permission first
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true })
    } catch {
      setError('Microphone permission denied. Please allow microphone access and try again.')
      return
    }
    
    setError(null)
    finalTranscriptRef.current = ''
    setTranscript('')
    setInterimTranscript('')
    setIsListening(true)
    
    try {
      recognitionRef.current.start()
    } catch {
      // Already started or other error
    }
  }, [isSupported])

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
    }
    setIsListening(false)
  }, [])

  const resetTranscript = useCallback(() => {
    finalTranscriptRef.current = ''
    setTranscript('')
    setInterimTranscript('')
  }, [])

  return {
    isListening,
    transcript,
    interimTranscript,
    isSupported,
    startListening,
    stopListening,
    resetTranscript,
    error,
  }
}
